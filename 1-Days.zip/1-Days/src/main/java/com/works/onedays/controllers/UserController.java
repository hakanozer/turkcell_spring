package com.works.onedays.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import props.Category;
import props.UserProp;

@Controller
public class UserController {
	
	List<UserProp> ls = new ArrayList<UserProp>();
	
	public UserController() {
		System.out.println("UserController call");
	}
	
	
	@GetMapping("/user")
	public String user( Model model ) {
		model.addAttribute("ls", ls);
		model.addAttribute("cls", allCat());
		return "user";
	}

	
	@PostMapping("/userAdd")
	public String userAdd( UserProp us ) {
		//System.out.println(" nameSurname: " + us.getNameSurname() + " email: "+ us.getEmail());
		ls.add(us);
		return "redirect:/user";
	}
	
	
	@GetMapping("/userDelete/{mail}")
	public String userDelete( @PathVariable String mail ) {
		
		int removeIndex = -1;
		for(int i = 0; i<ls.size(); i++) {
			if (ls.get(i).getEmail().equals(mail)) {
				removeIndex = i;
				break;
			}
		}
		
		if (removeIndex > -1) {
			ls.remove(removeIndex);
		}
		
		return "redirect:/user";
	}
	
	
	public List<Category> allCat() {
		List<Category> cls = new ArrayList<>();
		
		Category c1 = new Category("Buzbolabı", 1000);
		Category c2 = new Category("Televizyon", 2000);
		Category c3 = new Category("Tablet", 3000);
		Category c4 = new Category("Bilgisayar", 4000);
		
		cls.add(c1);
		cls.add(c2);
		cls.add(c3);
		cls.add(c4);
		
		return cls;
	}
	
	@GetMapping("/catDetail")
	public String catDetail( @RequestParam int cid, Model model ) {
		model.addAttribute("cid", cid);
		return "category";
	}

}
