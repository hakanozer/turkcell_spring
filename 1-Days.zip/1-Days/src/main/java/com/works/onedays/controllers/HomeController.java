package com.works.onedays.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import props.Product;

@Controller
public class HomeController {
	
	
	@GetMapping({"", "/", "site"})
	public String home( Model model, Random rd ) {
		model.addAttribute("name", "Zehra Bilsin");
		model.addAttribute("age", rd.nextInt(100));
		model.addAttribute("ls", allResult());
		model.addAttribute("pls", proAllResult());
		return "home";
	}
	
	
	public List<String> allResult() {
		List<String> ls = new ArrayList<>();
		
		for (int i = 0; i < 10; i++) {
			ls.add("Name : " + i);
		}
		
		return ls;
	}

	
	
	public List<Product> proAllResult() {
		List<Product> ls = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			Product pr = new Product();
			pr.setTitle("Product : " + i);
			pr.setPrice(i * 10);
			ls.add(pr);
		}
		return ls;
	}
	
	
	
}
