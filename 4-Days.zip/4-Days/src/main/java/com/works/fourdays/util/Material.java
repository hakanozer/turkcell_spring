package com.works.fourdays.util;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

public class Material {
	
	
	public static String user() {
		
		Authentication aut = SecurityContextHolder.getContext().getAuthentication();
		
		Collection<? extends GrantedAuthority> cls = aut.getAuthorities();
		for (GrantedAuthority item : cls) {
			System.out.println(item.getAuthority());
		}
		
		String name = aut.getName();
		System.out.println("Name : " + name);
		System.out.println("Detail : " + aut.getDetails());
		
		/*
		Map<String, Object> info = (Map<String, Object>) aut.getDetails();
		Set<String> keys = info.keySet();
		for (String key : keys) {
			System.out.println(key + " Val : " + info.get(key));
		}
		*/
		
		return name;
		
	}

}
