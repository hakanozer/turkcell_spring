package com.works.threedays.restcontoller;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.View;

import com.rometools.rome.feed.synd.SyndEntry;
import com.rometools.rome.feed.synd.SyndFeed;
import com.rometools.rome.io.SyndFeedInput;
import com.rometools.rome.io.XmlReader;
import com.works.threedays.rss.RssFeedView;

@RestController
public class RSServicesController {

	
	@Autowired RssFeedView view;
	
	@GetMapping("/rss")
	public View rss() {
		return view;
	}
	
	
	
	
	@GetMapping("/rssRead")
	public Map<String, Object> rssRead() {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		
		String url = "http://localhost:8095/rss";
		try ( XmlReader reader = new XmlReader(new URL(url)) ) {
			SyndFeed feed = new SyndFeedInput().build(reader);
			
			for (SyndEntry item : feed.getEntries()) {
				System.out.println(item.getTitle());
				System.out.println(item.getLink());
			}
			
			
			hm.put("rss", feed);
		} catch (Exception e) {
			System.err.println("Rss Read Error : " + e);
		}
		
		return hm;
	}
	
	
	@GetMapping("/xmlRead")
	public Map<String, Object> xmlRead() {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		List<HashMap<String, String>> ls = new ArrayList<HashMap<String,String>>(); 
		try {
			String url = "https://www.tcmb.gov.tr/kurlar/today.xml";
			String data = Jsoup.connect(url).get().toString();
			Document doc = Jsoup.parse(data, "", Parser.xmlParser());
			Elements elements = doc.getElementsByTag("Currency");
			for (Element element : elements) {
				HashMap<String, String> h = new HashMap<>();
				String Isim = element.getElementsByTag("Isim").text();
				String BanknoteSelling = element.getElementsByTag("BanknoteSelling").text();
				String BanknoteBuying = element.getElementsByTag("BanknoteBuying").text();
				h.put("Isim", Isim);
				h.put("BanknoteSelling", BanknoteSelling);
				h.put("BanknoteBuying", BanknoteBuying);
				ls.add(h);
			}
		} catch (Exception e) {
			System.err.println("xml read error : " + e);
		}
		
		hm.put("Currencies", ls);
		
		return hm;
	}
	
	
	
	
}
