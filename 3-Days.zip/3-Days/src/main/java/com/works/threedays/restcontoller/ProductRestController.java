package com.works.threedays.restcontoller;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.works.threedays.models.Product;
import com.works.threedays.repostories.ProductRepository;

@RestController
public class ProductRestController {

	@Autowired ProductRepository pr;
	
	@PostMapping("/prinsert")
	public Map<String, Object> prinsert( @RequestBody Product pro ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("statu", true);
		hm.put("message", "İşlem Başarılı");
		hm.put("product", pr.saveAndFlush(pro));
		return hm;
	}
	
	
	@GetMapping("/allProduct")
	@Cacheable("allProduct")
	public Map<String, Object> allProduct() {
		Map<String, Object> hm = new LinkedHashMap<>();
		List<Product> ls = pr.findAll();
		hm.put("statu", true);
		hm.put("message", "İşlem Başarılı");
		hm.put("size", ls.size());
		hm.put("allProduct", ls);
		return hm;
	}
	
	
	@DeleteMapping("/productDelete")
	public Map<String, Object> productDelete( int pid ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		try {
			pr.deleteById(pid);
			hm.put("statu", true);
			hm.put("message", "Delete item success");
			hm.put("delete pid", pid);
		} catch (Exception e) {
			hm.put("statu", false);
			hm.put("message", "Delete item Fail");
		}
		return hm;
	}
	
	
	@GetMapping("/singleProduct")
	public Map<String, Object> singleProduct( int pid ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("statu", true);
		hm.put("message", "İşlem Başarılı");
		hm.put("date", new Date());
		Product pro = pr.findById(pid).get();
		hm.put("single", pro);
		return hm;
	}
	
	
	@PutMapping("/updateProduct")
	public Map<String, Object> updateProduct( Product pro ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("statu", true);
		hm.put("message", "İşlem Başarılı");
		hm.put("date", new Date());
		Product prop = pr.saveAndFlush(pro);
		hm.put("single", prop);
		return hm;
	}
	
	
	@GetMapping("/priceSearch")
	public Map<String, Object> priceSearch( double price, String title ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("statu", true);
		hm.put("message", "İşlem Başarılı");
		String t = title == null ? "" : title;
		List<Product> ls = pr.priceProduct(price, t);
		hm.put("size", ls.size());
		hm.put("priceProduct", ls);
		return hm;
	}
	
	
	
}
