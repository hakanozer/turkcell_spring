package com.works.threedays.repostories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.works.threedays.models.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
	
	@Query(" from Product p where p.price > ?1 and p.title like %?2% ")
	List<Product> priceProduct( double price, String title );
	

}
