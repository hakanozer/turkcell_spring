package com.works.threedays.rss;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.feed.AbstractRssFeedView;

import com.rometools.rome.feed.rss.Channel;
import com.rometools.rome.feed.rss.Description;
import com.rometools.rome.feed.rss.Item;

@Component
public class RssFeedView extends AbstractRssFeedView {

	@Override
	protected void buildFeedMetadata(Map<String, Object> model, Channel feed, HttpServletRequest request) {
		feed.setTitle("RSS Title");
		feed.setDescription("RSS Feed Desc");
		feed.setLink("htttp://google.com.tr");
	}
	
	
	@Override
	protected List<Item> buildFeedItems(Map<String, Object> model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		List<Item> ls = new ArrayList<Item>();
		
		for (int i = 0; i < 10; i++) {
			Item item = new Item();
			item.setTitle("RSS Title " + i);
			Description ds = new Description();
			ds.setType(DEFAULT_CONTENT_TYPE);
			ds.setValue("RSS Desc " + i );
			item.setDescription(ds);
			item.setLink("https://www.feedforall.com/sample.xml");
			item.setPubDate(new Date());
			ls.add(item);
		}
		
		
		return ls;
	}

	
	
}
