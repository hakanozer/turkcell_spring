package com.works.threedays.restcontoller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.google.gson.Gson;
import com.works.threedays.props.Article;
import com.works.threedays.props.Bilgiler;
import com.works.threedays.props.JsonData;
import com.works.threedays.props.JsonNews;

@RestController
public class ClientRestController {
	
	
	@GetMapping("/servicesProduct")
	public Map<String, Object> servicesProduct() {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		
		String url = "http://newsapi.org/v2/top-headlines";
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url)
				.queryParam("sources", "google-news-in")
				.queryParam("apiKey", "38a9e086f10b445faabb4461c4aa71f8");
		String urlParam = builder.toUriString();
				
		RestTemplate restTemplate = new RestTemplate();
		String data = restTemplate.getForObject(urlParam, String.class);
		
		Gson gson = new Gson();
		JsonNews jsonData = gson.fromJson(data, JsonNews.class);
		
		List<Article> ls = jsonData.getArticles();
		
		hm.put("size", ls.size());
		hm.put("allNews", ls);
		
		return hm;
	}
	
	

}
